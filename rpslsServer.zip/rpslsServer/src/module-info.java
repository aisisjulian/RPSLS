module rpslsServer {
    requires javafx.fxml;
    requires javafx.controls;

    opens server;
}