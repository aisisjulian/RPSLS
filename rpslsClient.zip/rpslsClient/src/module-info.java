module rpslsClient {
    requires javafx.fxml;
    requires javafx.controls;

    opens client;
}